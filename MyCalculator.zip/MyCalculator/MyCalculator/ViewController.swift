//
//  ViewController.swift
//  MyCalculator
//
//  Created by Александр Харитонов on 28.03.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

